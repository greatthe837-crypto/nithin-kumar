# Wildlife Acoustics — Sound Classification Website

A responsive educational/research showcase with browser-side audio classification using Google's YAMNet model through MediaPipe Tasks Audio.

## Features
- Premium forest-green and gold responsive website
- Project overview, wildlife education and workflow sections
- Audio upload interface with top-5 sound-event predictions
- YAMNet runs in the visitor's browser; uploaded audio is not sent to the Flask server
- WAV, MP3, FLAC and OGG where supported by the visitor's browser; maximum 25 MB / 120 seconds
- Lightweight Flask server (no TensorFlow, TensorFlow Hub or librosa)

## Requirements
- Python 3.10 or 3.11 recommended
- Internet connection so the browser can download MediaPipe's WebAssembly files and YAMNet model on first analysis
- A modern browser such as current Chrome or Edge

## Run locally (Windows)
Double-click `START_WEBSITE.bat`, or run:

```powershell
py -3.11 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000.

## Deploy on Render
- Runtime: Python
- Build command: `pip install -r requirements.txt`
- Start command: `gunicorn app:app`
- Root directory: leave blank

The app no longer loads TensorFlow on Render, which avoids the memory-heavy server-side model that caused the free instance worker to be killed. The browser downloads and runs the model when someone uses the analyzer.

## About the AI
YAMNet is a pretrained general sound-event classifier trained on AudioSet. It predicts sound categories, some of which are wildlife-related (such as bird, frog or insect sounds). It does **not** guarantee identification of a particular species and should not be used as a conservation decision tool without validation.

## Important notes
- The first analysis requires internet access and may take longer while the model downloads.
- Audio decoding depends on the browser. If a format cannot be decoded, try WAV or MP3.
- Classification runs on the visitor's device; the website's Flask server does not receive the audio file.
- The page uses externally hosted Google Fonts and imagery; replace these with licensed/local assets if publishing.
