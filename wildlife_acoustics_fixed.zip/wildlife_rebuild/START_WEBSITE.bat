@echo off
setlocal
cd /d "%~dp0"
title Wildlife Acoustics - Website Launcher

echo ==========================================
echo   WILDLIFE ACOUSTICS WEBSITE
echo ==========================================
echo.

where py >nul 2>nul
if errorlevel 1 (
  echo Python launcher was not found.
  echo Please install Python 3.11 from https://www.python.org/downloads/
  echo During installation, enable "Add Python to PATH".
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo Creating the Python environment...
  py -3.11 -m venv .venv
  if errorlevel 1 (
    echo Could not create the environment. Check that Python 3.11 is installed.
    pause
    exit /b 1
  )
)

echo.
echo Installing or checking required packages...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 (
  echo Package installer failed. Check your internet connection.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
  echo Package installation failed. The error is shown above.
  pause
  exit /b 1
)

echo.
echo Starting the website...
echo Keep this window open while using the website.
start "" powershell -NoProfile -WindowStyle Hidden -Command "Start-Sleep -Seconds 8; Start-Process 'http://127.0.0.1:5000'"
".venv\Scripts\python.exe" app.py

echo.
echo The website server has stopped.
pause
