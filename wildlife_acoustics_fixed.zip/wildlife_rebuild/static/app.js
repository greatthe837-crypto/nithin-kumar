const fileInput = document.getElementById("audioFile");
const analyzeBtn = document.getElementById("analyzeBtn");
const fileMeta = document.getElementById("fileMeta");
const statusBox = document.getElementById("status");
const resultsBox = document.getElementById("results");
let selectedFile = null;
let classifierPromise = null;

const MODEL_URL = "https://storage.googleapis.com/mediapipe-models/audio_classifier/yamnet/float32/latest/yamnet.tflite";
const WASM_URL = "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-audio@0.10.14/wasm";

fileInput.addEventListener("change", () => {
  selectedFile = fileInput.files[0] || null;
  resultsBox.hidden = true;
  statusBox.textContent = "";
  analyzeBtn.disabled = !selectedFile;
  fileMeta.textContent = selectedFile
    ? `${selectedFile.name} · ${(selectedFile.size / 1024 / 1024).toFixed(2)} MB`
    : "WAV, MP3, FLAC or OGG · Up to 25 MB · Maximum 120 seconds";
});

async function getClassifier() {
  if (!classifierPromise) {
    classifierPromise = (async () => {
      const { AudioClassifier, FilesetResolver } = await import(
        "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-audio@0.10.14"
      );
      const fileset = await FilesetResolver.forAudioTasks(WASM_URL);
      return AudioClassifier.createFromOptions(fileset, {
        baseOptions: { modelAssetPath: MODEL_URL },
        runningMode: "AUDIO_CLIPS",
        maxResults: 5
      });
    })().catch(error => {
      classifierPromise = null;
      throw error;
    });
  }
  return classifierPromise;
}

function showResults(predictions) {
  resultsBox.replaceChildren();
  const heading = document.createElement("h4");
  heading.textContent = "Top sound predictions";
  resultsBox.appendChild(heading);

  predictions.forEach(item => {
    const row = document.createElement("div");
    row.className = "result-row";
    const left = document.createElement("div");
    const label = document.createElement("div");
    label.textContent = item.label;
    const bar = document.createElement("div");
    bar.className = "bar";
    const fill = document.createElement("i");
    fill.style.width = `${Math.min(100, item.confidence)}%`;
    bar.appendChild(fill);
    left.append(label, bar);
    const score = document.createElement("div");
    score.className = "confidence";
    score.textContent = `${item.confidence.toFixed(2)}%`;
    row.append(left, score);
    resultsBox.appendChild(row);
  });

  const note = document.createElement("p");
  note.className = "result-note";
  note.textContent = "Google YAMNet (AudioSet). Predictions are sound-event estimates, not verified species identifications. Recording quality, distance, background noise and overlapping calls can affect results. Audio is processed in your browser and is not uploaded to this website.";
  resultsBox.appendChild(note);
  resultsBox.hidden = false;

  const wildlifeTerms = ["bird", "animal", "frog", "cricket", "insect", "dog", "cat", "cow", "horse", "sheep", "pig", "rooster", "crow", "owl", "snake", "whale", "elephant", "monkey", "lion", "tiger", "wolf", "fox", "bat"];
  const likelyWildlife = predictions.slice(0, 3).some(item =>
    wildlifeTerms.some(term => item.label.toLowerCase().includes(term))
  );
  statusBox.textContent = likelyWildlife
    ? "Analysis complete. Wildlife-related sound categories appear among the leading predictions."
    : "Analysis complete. No obvious wildlife category appeared in the leading predictions.";
}

analyzeBtn.addEventListener("click", async () => {
  if (!selectedFile) return;
  if (selectedFile.size > 25 * 1024 * 1024) {
    statusBox.textContent = "Please choose a file smaller than 25 MB.";
    return;
  }

  analyzeBtn.disabled = true;
  resultsBox.hidden = true;
  statusBox.textContent = "Loading the AI model in your browser. The first run may take a little longer…";

  let audioContext;
  try {
    const classifier = await getClassifier();
    statusBox.textContent = "Preparing your recording…";
    const bytes = await selectedFile.arrayBuffer();
    audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const audioBuffer = await audioContext.decodeAudioData(bytes);

    if (audioBuffer.duration > 120) {
      throw new Error("Please upload an audio clip of 120 seconds or less.");
    }
    if (audioBuffer.duration < 0.1) {
      throw new Error("Please upload an audio clip at least 0.1 seconds long.");
    }

    const channels = [];
    for (let channel = 0; channel < audioBuffer.numberOfChannels; channel++) {
      channels.push(audioBuffer.getChannelData(channel));
    }
    const mono = new Float32Array(audioBuffer.length);
    for (const channel of channels) {
      for (let i = 0; i < mono.length; i++) mono[i] += channel[i] / channels.length;
    }

    statusBox.textContent = "Analyzing sound…";
    const windows = classifier.classify(mono, audioBuffer.sampleRate);
    const totals = new Map();
    let count = 0;
    for (const windowResult of windows) {
      const categories = windowResult.classifications?.[0]?.categories || [];
      for (const category of categories) {
        const previous = totals.get(category.categoryName) || 0;
        totals.set(category.categoryName, previous + category.score);
      }
      if (categories.length) count++;
    }
    if (!count || !totals.size) {
      throw new Error("The model did not return predictions. Please try a clearer audio recording.");
    }
    const predictions = [...totals.entries()]
      .map(([label, total]) => ({ label, confidence: (total / count) * 100 }))
      .sort((a, b) => b.confidence - a.confidence)
      .slice(0, 5);
    showResults(predictions);
  } catch (error) {
    const message = error?.message || "Audio analysis failed. Please try another audio file.";
    statusBox.textContent = message.includes("decode")
      ? "This audio format could not be opened by your browser. Please try a WAV or MP3 file."
      : message;
  } finally {
    if (audioContext && audioContext.state !== "closed") await audioContext.close();
    analyzeBtn.disabled = !selectedFile;
  }
});
